name = "ntap"
from .models import *

__all__ = ["Model","SVM","LM","RNN"]